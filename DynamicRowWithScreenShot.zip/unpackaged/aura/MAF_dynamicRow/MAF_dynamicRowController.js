({
    
    // function call on component Load
    doInit: function(component, event, helper) {
        // create a Default RowItem [Split Installment Instance] on first time Component Load
        // by call this helper function
        helper.installmentData(component);
        helper.createObjectData(component, event);
    },
    
    // function for save the Records 
    Save: function(component, event, helper) {

        // first call the helper function in if block which will return true or false.
        // this helper function check the "first Name" will not be blank on each row.
        if (helper.validateRequired(component, event)) {
            // call the apex class method for save the Split List
            // with pass the Split List attribute to method param. 
            var totalpercentage=0;
            var listOfSplit = component.get("v.insList");
            var dueDate = component.get("v.nxtinstallment.Due_Date__c");
            var flag= false;
            console.log('inside due date:'+dueDate);
            console.log('inside for loop1:'+totalpercentage);
            for(var i=0;i<listOfSplit.length;i++){
                console.log('inside for loop2:'+totalpercentage);
                totalpercentage = totalpercentage + parseInt(listOfSplit[i].Split__c);
                if(dueDate < listOfSplit[i].Due_Date__c){
                    flag = true; 
                }
                var lastDueDate= listOfSplit[i].Due_Date__c;
                console.log('inside for loop3:'+totalpercentage);
            }
            console.log(totalpercentage);
            if(totalpercentage !=100){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": "Please Check total %",
                    "type":"error"
                });
                toastEvent.fire();
                return;
            }if(flag){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": "Due Date should not excedd the next Installmet Due date",
                    "type":"error"
                });
                toastEvent.fire();
                return;
            }
            helper.showSpinner(component,event,helper);
            var action = component.get("c.saveSplitRec");
            action.setParams({
                "SplitRecList": component.get("v.insList")
            });
            // set call back 
            action.setCallback(this, function(response) {
                console.log(response);
                var state = response.getState();
                if (state === "SUCCESS") {
                    // if response if success then reset/blank the 'contactList' Attribute 
                    // and call the common helper method for create a default Object Data to Contact List 
                    component.set("v.insList", []);
                    helper.createObjectData(component, event);
                    helper.hideSpinner(component,event,helper);
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": "Success:"+response.getState(),
                        "type":"success"
                    });
                    toastEvent.fire();
                    $A.get("e.force:closeQuickAction").fire();
                    
                }else{
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": "Error Occured:"+response.getState(),
                        "type":"error"
                    });
                    toastEvent.fire();
                    $A.get("e.force:closeQuickAction").fire();
                }
            });
            // enqueue the server side action  
            $A.enqueueAction(action);
        }
    },
    
    // function for create new object Row in Contact List 
    addNewRow: function(component, event, helper) {
        // call the comman "createObjectData" helper method for add new Object Row to List  
        helper.createObjectData(component, event);
    },
    
    // function for delete the row 
    removeDeletedRow: function(component, event, helper) {
        // get the selected row Index for delete, from Lightning Event Attribute  
        var index = event.getParam("indexVar");
        // get the all List (contactList attribute) and remove the Object Element Using splice method    
        var AllRowsList = component.get("v.insList");
        AllRowsList.splice(index, 1);
        // set the contactList after remove selected row element  
        component.set("v.insList", AllRowsList);
    },
    
})