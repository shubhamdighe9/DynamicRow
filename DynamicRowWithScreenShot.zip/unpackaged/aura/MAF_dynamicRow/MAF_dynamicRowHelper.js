({
    installmentData : function(component){
        var recId = component.get("v.recordId");
        var action = component.get("c.getInstallment");
        //passing the list of pending record for approval
        action.setParams({installmentId:recId});
        action.setCallback(this,$A.getCallback(function(response){
            if(response.getState()==="SUCCESS"){
                var data = response.getReturnValue();
                console.log('-->'+JSON.stringify(data));
                component.set("v.installment",data.curInstllment);
                 component.set("v.nxtinstallment",data.nxtInstllment);
                console.log('REMAINING AMOUNT:::'+component.get("v.installment").Remaining_Amount__c);
                if(component.get("v.installment").Remaining_Amount__c == '0' || component.get("v.installment").Request__c=='Splited Installment'){
                    console.log('REMAINING AMOUNT 2'+component.get("v.installment").Remaining_Amount__c);
                    component.set("v.headingValue","This Installment is Already Paid/Request for Split is Submitted can't not be splitted");
                    component.set("v.isVisible",false);
                }
                var headValue = component.get('v.headingValue');
                if(headValue != 'Create Split records'){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Info Message',
                        message: 'This Installment is Already Paid/Request for Split is Submitted can not be splitted',
                        type: 'info',
                        duration:' 5000',
                    });
                    toastEvent.fire();
                    
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
                    dismissActionPanel.fire();
                }
            }
        }));
        $A.enqueueAction(action);
    },
    createObjectData: function(component, event) {
        // get the insList from component and add(push) New Object to List  
        var RowItemList = component.get("v.insList");
        RowItemList.push({
            'sobjectType': 'Installment_Split__c',
            'Name':'',
            'Split__c': '',
            'Due_Date__c': '',
            'Amount__c': '',
            'Installment__c':component.get("v.recordId")
        });
        // set the updated list to attribute (insList) again    
        component.set("v.insList", RowItemList);
    },
    // helper function for check if first Name is not null/blank on save  
    validateRequired: function(component, event) {
        var isValid = true;
        var allSplitRows = component.get("v.insList");
        for (var indexVar = 0; indexVar < allSplitRows.length; indexVar++) {
            if (allSplitRows[indexVar].Split__c == '') {
                isValid = false;
                alert('Split % Can\'t be Blank on Row Number ' + (indexVar + 1));
            }
        }
        return isValid;
    },
     showSpinner: function (component,event,helper) {
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
    },
     
    hideSpinner: function (component,event,helper) {
        var spinner = component.find("mySpinner");
        $A.util.addClass(spinner, "slds-hide");
    }
})