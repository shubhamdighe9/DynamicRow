({
    AddNewRow : function(component, event, helper){
       // fire the AddNewRowEvt Lightning Event 
        component.getEvent("AddRowEvt").fire();     
    },
    
    removeRow : function(component, event, helper){
     // fire the DeleteRowEvt Lightning Event and pass the deleted Row Index to Event parameter/attribute
       component.getEvent("DeleteRowEvt").setParams({"indexVar" : component.get("v.rowIndex") }).fire();
    }, 
    
    calculateAmount : function(component, event, helper){
    	var amt = component.get("v.installment.Remaining_Amount__c");
        var perc = component.find("percent").get("v.value");
        var splitAmount = amt * (perc/100);
        var splamount=splitAmount.toFixed(2);
        component.set("v.splitRecord.Amount__c",splamount);
    
    }, 
    calculatePercentage : function(component, event, helper){
     	var amt = component.get("v.installment.Remaining_Amount__c");
        var splitAmount = component.find("amt").get("v.value");
        var spAmount = ((splitAmount/amt) * 100);
        console.log('--@@@1---->'+spAmount);
        var samount=spAmount.toFixed(2);
        console.log('--@@@2---->'+samount);
        component.set("v.splitRecord.Split__c",samount);
    
    }, 
      /*checkDuedate : function(component, event, helper){
     	var dueDate = component.get("v.nxtinstallment.Due_Date__c");
        var splitDate = component.find("duedate").get("v.value");
        console.log(dueDate);
        console.log(splitDate);
        if(splitDate > dueDate){
            	var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": "Due Date should be less than Next Payment Schedule due date.",
                        "type":"error"
                    });
                    toastEvent.fire();
                return;  
         }
    }, */
  
  
})